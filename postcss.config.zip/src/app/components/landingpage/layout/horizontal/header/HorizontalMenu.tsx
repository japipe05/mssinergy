import React from "react";
import Navigation from "@/app/DashboardLayout/layout/horizontal/navbar/Navigation";
const HorizontalMenu = () => {
  return (
    <>
      <Navigation />
    </>
  );
};

export default HorizontalMenu;
