"use client";
import React from "react";
import Notelist from "./Notelist";

const NotesSidebar = () => {
  
  return (
    <>
      <div className="left-part">
        <Notelist/>
      </div>
    </>
  );
};

export default NotesSidebar;
